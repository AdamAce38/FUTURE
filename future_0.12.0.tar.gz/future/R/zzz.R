## covr: skip=all
.onLoad <- function(libname, pkgname) {
  uuid()
  plan("default")
}
