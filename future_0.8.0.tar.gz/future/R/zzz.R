## covr: skip=all
.onLoad <- function(libname, pkgname) {
  plan("default")
}
