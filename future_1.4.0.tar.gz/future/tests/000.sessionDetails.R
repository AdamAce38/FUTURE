library("future")
sessionDetails()

